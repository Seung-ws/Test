package eun.myself.myapp.board.model;

public class BoardCategory {
	private int category_id;
	private int category_class1;
	private int category_class2;
	private String category_name;
	private String category_description;
	private int category_order;
	
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public int getCategory_class1() {
		return category_class1;
	}
	public void setCategory_class1(int category_class1) {
		this.category_class1 = category_class1;
	}
	public int getCategory_class2() {
		return category_class2;
	}
	public void setCategory_class2(int category_class2) {
		this.category_class2 = category_class2;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getCategory_description() {
		return category_description;
	}
	public void setCategory_description(String category_description) {
		this.category_description = category_description;
	}
	public int getCategory_order() {
		return category_order;
	}
	public void setCategory_order(int category_order) {
		this.category_order = category_order;
	}

	
	
}
